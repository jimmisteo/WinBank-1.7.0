#include "moneybox.h"

moneybox::moneybox() {
	goal = 0;
	saved = 0;
	for (int i = 0; i < 8; i++) {
		end_date[i] = 0;
	}
	category = "NONE";
}
