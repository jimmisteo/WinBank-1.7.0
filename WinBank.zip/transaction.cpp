#include "transaction.h"
#include <string>
#include <ctime>

transaction::transaction() {
    int k[12];
    srand(time(NULL));
    for (int i = 0; i < 12; i++) {
        k[i] = rand() % 9;
    }
    code = std::to_string(k[0]) + std::to_string(k[1]) + std::to_string(k[2]) + std::to_string(k[3]) + std::to_string(k[4]) + std::to_string(k[5]) + std::to_string(k[6]) + std::to_string(k[7]) + std::to_string(k[8]) + std::to_string(k[9]) + std::to_string(k[10]) + std::to_string(k[11]);


    std::time_t currentTime = std::time(nullptr);
    std::tm localTime;
    localtime_s(&localTime, &currentTime);
    std::strftime(date, sizeof(date), "%d/%m/%Y", &localTime);
    std::strftime(tim, sizeof(tim), "%H:%M:%S", &localTime);
    std::strftime(day, sizeof(day), "%A", &localTime);
}