#pragma once
#include "bank_account.h"

class transaction :public bank_account
{
public:
	std::string code;
	char date[11];
	char tim[9];
	char day[16];
	float amount;
	std::string type;
	float new_balance;
	std::string other;
	transaction();
};